// Customer.hpp
// ICS46 Winter 2021 Project 2
// Name: Keyu Zhang
// ID: 19898090
// UCINetID: keyuz4

// a struct that represents a customer

#ifndef CUSTOMER_HPP
#define CUSTOMER_HPP

struct Customer
{
    // time that the customer entered the queue
    unsigned int enterQueueTime;
};

#endif
